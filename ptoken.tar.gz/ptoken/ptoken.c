/*
  +----------------------------------------------------------------------+
  | PHP Version 7                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2015 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: Lei Wu <352386674@qq.com>                                    |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_ptoken.h"

ZEND_DECLARE_MODULE_GLOBALS(ptoken)

void print_scanner_emit_token(zend_php_scanner_event event, int token, int line)
{
    zend_string* token_val = zend_string_init((char *) LANG_SCNG(yy_text),
                                              LANG_SCNG(yy_leng), 0);

    token_info* info = (token_info*) PTOKEN_MALLOC(sizeof(token_info));
    info->line = line;
    info->token_number   = token;
    info->is_print_token = IS_PRINT_TOKEN(token);

    if(info->is_print_token)
    {
        info->u.ascii = token;
    }
    else
    {
        info->u.token = GET_TOKEN(token);
    }

    info->val  = token_val;
    info->next = NULL;

    AST_G(cursor)->next = info;
    AST_G(cursor) = info;
}

/* {{{ print_token
 */
PHP_FUNCTION(print_token)
{
    token_info* t = PTOKEN_G(token)->next;

    while(t)
    {
        // ascii 包含一些不可见字符(e.g 不可打印字符)如 \r\n
        if(t->is_print_token)
        {

            printf(
                    "---- token: %c ---------- val: %c ---- number: %d ---- line: %d ----\r\n"
                    , t->token_number, t->u.ascii, t->token_number, t->line);
        }
        else
        {
            printf(
                    "---- token: %s ---------- val: %s ---- number: %d ---- line: %d ----\r\n"
                    , t->u.token, ZSTR_VAL(t->val), t->token_number, t->line);
        }

        fflush(stdout);

        t = t->next;
    }
}
/* }}} */

static int le_ptoken;

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(ptoken)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(ptoken)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(ptoken)
{
    LANG_SCNG(on_event) = print_scanner_emit_token;

    PTOKEN_G(token) = (token_info*) PTOKEN_MALLOC(sizeof(token_info));
    PTOKEN_G(token)->val  = NULL;
    PTOKEN_G(token)->next = NULL;

    PTOKEN_G(cursor) = PTOKEN_G(token);

#if defined(COMPILE_DL_PTOKEN) && defined(ZTS)
	ZEND_TSRMLS_CACHE_UPDATE();
#endif
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(ptoken)
{
    token_info* tmp;
    token_info* token = PTOKEN_G(token);

    while(token)
    {
        if(token->val)
        {
            zend_string_free(token->val);
        }

        tmp   = token;
        token = token->next;

        PTOKEN_FREE(tmp);
    }

	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(ptoken)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "ptoken support", "enabled");
	php_info_print_table_end();
}
/* }}} */

/* {{{ ptoken_functions[]
 *
 * Every user visible function must have an entry in ptoken_functions[].
 */
const zend_function_entry ptoken_functions[] = {
	PHP_FE(print_token,	NULL)
	PHP_FE_END	/* Must be the last line in ptoken_functions[] */
};
/* }}} */

/* {{{ ptoken_module_entry
 */
zend_module_entry ptoken_module_entry = {
	STANDARD_MODULE_HEADER,
	"ptoken",
	ptoken_functions,
	PHP_MINIT(ptoken),
	PHP_MSHUTDOWN(ptoken),
	PHP_RINIT(ptoken),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(ptoken),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(ptoken),
	PHP_PTOKEN_VERSION,
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_PTOKEN
#ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE();
#endif
ZEND_GET_MODULE(ptoken)
#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
