/*
  +----------------------------------------------------------------------+
  | PHP Version 7                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2015 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: Lei Wu <352386674@qq.com>                                    |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifndef PHP_PTOKEN_H
#define PHP_PTOKEN_H

extern zend_module_entry ptoken_module_entry;
#define phpext_ptoken_ptr &ptoken_module_entry

#define PHP_PTOKEN_VERSION "0.1.0" /* Replace with version number for your extension */

// malloc
#define PTOKEN_MALLOC(v) pemalloc((v), 0)
#define PTOKEN_FREE(v)   pefree((v), 0)

// 由于某些token直接使用值返回没有token
#define IS_PRINT_TOKEN(c)  (((c) > (0) && (c) < (177)))

// 计算token索引位置
#define CALC_TOKEN_INDEX(token_num) ((token_num) % (257))

// 获取token
#define GET_TOKEN(token_num) (tokens[CALC_TOKEN_INDEX((token_num))])

typedef struct _token_info token_info;

struct _token_info {
    int line;
    int token_number;
    int is_print_token;
    union {
        int         ascii;
        const char* token;
    } u;
    zend_string*        val;
    struct _token_info* next;
};

const static char* tokens[] = {
        "END",
        "T_INCLUDE",
        "T_INCLUDE_ONCE",
        "T_EVAL",
        "T_REQUIRE",
        "T_REQUIRE_ONCE",
        "T_LOGICAL_OR",
        "T_LOGICAL_XOR",
        "T_LOGICAL_AND",
        "T_PRINT",
        "T_YIELD",
        "T_DOUBLE_ARROW",
        "T_YIELD_FROM",
        "T_PLUS_EQUAL",
        "T_MINUS_EQUAL",
        "T_MUL_EQUAL",
        "T_DIV_EQUAL",
        "T_CONCAT_EQUAL",
        "T_MOD_EQUAL",
        "T_AND_EQUAL",
        "T_OR_EQUAL",
        "T_XOR_EQUAL",
        "T_SL_EQUAL",
        "T_SR_EQUAL",
        "T_POW_EQUAL",
        "T_COALESCE",
        "T_BOOLEAN_OR",
        "T_BOOLEAN_AND",
        "T_IS_EQUAL",
        "T_IS_NOT_EQUAL",
        "T_IS_IDENTICAL",
        "T_IS_NOT_IDENTICAL",
        "T_SPACESHIP",
        "T_IS_SMALLER_OR_EQUAL",
        "T_IS_GREATER_OR_EQUAL",
        "T_SL",
        "T_SR",
        "T_INSTANCEOF",
        "T_INC",
        "T_DEC",
        "T_INT_CAST",
        "T_DOUBLE_CAST",
        "T_STRING_CAST",
        "T_ARRAY_CAST",
        "T_OBJECT_CAST",
        "T_BOOL_CAST",
        "T_UNSET_CAST",
        "T_POW",
        "T_NEW",
        "T_CLONE",
        "T_NOELSE",
        "T_ELSEIF",
        "T_ELSE",
        "T_ENDIF",
        "T_STATIC",
        "T_ABSTRACT",
        "T_FINAL",
        "T_PRIVATE",
        "T_PROTECTED",
        "T_PUBLIC",
        "T_LNUMBER",
        "T_DNUMBER",
        "T_STRING",
        "T_VARIABLE",
        "T_INLINE_HTML",
        "T_ENCAPSED_AND_WHITESPACE",
        "T_CONSTANT_ENCAPSED_STRING",
        "T_STRING_VARNAME",
        "T_NUM_STRING",
        "T_EXIT",
        "T_IF",
        "T_ECHO",
        "T_DO",
        "T_WHILE",
        "T_ENDWHILE",
        "T_FOR",
        "T_ENDFOR",
        "T_FOREACH",
        "T_ENDFOREACH",
        "T_DECLARE",
        "T_ENDDECLARE",
        "T_AS",
        "T_SWITCH",
        "T_ENDSWITCH",
        "T_CASE",
        "T_DEFAULT",
        "T_BREAK",
        "T_CONTINUE",
        "T_GOTO",
        "T_FUNCTION",
        "T_CONST",
        "T_RETURN",
        "T_TRY",
        "T_CATCH",
        "T_FINALLY",
        "T_THROW",
        "T_USE",
        "T_INSTEADOF",
        "T_GLOBAL",
        "T_VAR",
        "T_UNSET",
        "T_ISSET",
        "T_EMPTY",
        "T_HALT_COMPILER",
        "T_CLASS",
        "T_TRAIT",
        "T_INTERFACE",
        "T_EXTENDS",
        "T_IMPLEMENTS",
        "T_OBJECT_OPERATOR",
        "T_LIST",
        "T_ARRAY",
        "T_CALLABLE",
        "T_LINE",
        "T_FILE",
        "T_DIR",
        "T_CLASS_C",
        "T_TRAIT_C",
        "T_METHOD_C",
        "T_FUNC_C",
        "T_COMMENT",
        "T_DOC_COMMENT",
        "T_OPEN_TAG",
        "T_OPEN_TAG_WITH_ECHO",
        "T_CLOSE_TAG",
        "T_WHITESPACE",
        "T_START_HEREDOC",
        "T_END_HEREDOC",
        "T_DOLLAR_OPEN_CURLY_BRACES",
        "T_CURLY_OPEN",
        "T_PAAMAYIM_NEKUDOTAYIM",
        "T_NAMESPACE",
        "T_NS_C",
        "T_NS_SEPARATOR",
        "T_ELLIPSIS",
        "T_ERROR",
};

#ifdef PHP_WIN32
#	define PHP_PTOKEN_API __declspec(dllexport)
#elif defined(__GNUC__) && __GNUC__ >= 4
#	define PHP_PTOKEN_API __attribute__ ((visibility("default")))
#else
#	define PHP_PTOKEN_API
#endif

#ifdef ZTS
#include "TSRM.h"
#endif

// token钩子函数
void print_scanner_emit_token(zend_php_scanner_event event, int token, int line);

PHP_FUNCTION(print_token);

ZEND_BEGIN_MODULE_GLOBALS(ptoken)
    token_info* token;
    token_info* cursor;
ZEND_END_MODULE_GLOBALS(ptoken)

#define PTOKEN_G(v) ZEND_MODULE_GLOBALS_ACCESSOR(ptoken, v)

#if defined(ZTS) && defined(COMPILE_DL_PTOKEN)
ZEND_TSRMLS_CACHE_EXTERN();
#endif

#endif	/* PHP_PTOKEN_H */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
